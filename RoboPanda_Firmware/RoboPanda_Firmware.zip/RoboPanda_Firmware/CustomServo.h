/*
 * CustomServo library: https://www.instructables.com/Make-your-own-low-cost-servo/
 */

#ifndef CustomServo_h
#define CustomServo_h
#include <Arduino.h>

class CServo
{
public :
  CServo();
	CServo(int pin1 , int pin2 , int feedbkpin);

	void drive(int ang);
	
	int read();
private :
	int _feedbkpin;
	int _pin1;
	int _pin2;


};

#endif